﻿using System;
using System.Collections.Generic;
using System.Linq;
using DemoLibs;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
	internal class Program

	{
		static void Main(string[] args)
		{
			Work work = new Work();	

			Random rand = new Random();	
			List<Work.Student> people = new List<Work.Student>()
			{
				new Work.Student("Шадрин Илья Олегович", 818, 2018),
				new Work.Student("Чернигин Марк Олегович", 818, 2018)
			};
			Console.WriteLine("Студенты ");
			foreach (var stud in people)
			{
				stud.PrintInfo();
			}

			//Console.WriteLine("Посещаемость");
			List<Work.Mark> mark = work.GetMarks(DateTime.Now, people);

			// Задание 1. Генерация оценок, посещаемости на 10 дней вперед,
			//начиная с текущей даты со списком переданных студентов		
			Console.WriteLine();
			Console.WriteLine("Задание 1. Генерация оценок, посещаемости на 10 дней вперед\nначиная с текущей даты со списком переданных студентов");
			List<Work.Mark> MR = work.GetMarks(DateTime.Today, people);
			MR.AddRange(work.GetMarks(DateTime.Parse("01.04.2022"), people));
			MR.AddRange(work.GetMarks(DateTime.Parse("01.05.2022"), people));
			for (int i = 0; i < MR.Count; i++)
            {
				Console.WriteLine(MR[i].Attendance + ": " + MR[i].Estimation);
            }

			//Задание 2. Вычисление среднего арифметического значения оценки в меньшую сторону. +
			Console.WriteLine();
			Console.WriteLine("Задание 2. Вычисление среднего арифметического значения оценки в меньшую сторону.");
			string[] atend = new string[] {"5", "5", "3", "4", "2" };
			Console.Write("Оценки: ");
			foreach (var at in atend)
            {
				Console.Write(at + ", ");
            }
			Console.WriteLine("Средний балл: " + work.MinAVG(atend));

			//Задание 3. Вычисление количество прогулов за месяц за период.
			Console.WriteLine();
			Console.WriteLine("Задание 3. Вычисление количество прогулов за месяц за период.");
			//Console.WriteLine("Количество прогулов: " + work.GetCountTruancy(mark));
			foreach (int i in work.GetCountTruancy(MR))
			{
				Console.WriteLine(i);
			}

			//Задание 4. Вычисление количество пропусков по болезни за месяц за период
			Console.WriteLine();
			Console.WriteLine("Задание 4. Вычисление количество пропусков по болезни за месяц за период");
			//Console.WriteLine("Количество пропусков по болезни: " + work.GetCountDisease(mark));
			foreach (int i in work.GetCountDisease(MR))
			{
				Console.WriteLine(i);
			}
			//Задание 5. Генерация номера студенческого билета в формате: yyyy.group.initial + 
			Console.WriteLine();
			Console.WriteLine("Задание 5. Генерация номера студенческого билета в формате: yyyy.group.initial");

			for (int i = 0; i < people.Count; i++)
			{
				Console.WriteLine(work.GetStudNumber(people[i].Year, people[i].Group, people[i].FIO));
			}

			Console.ReadKey();
		}
	}
}
