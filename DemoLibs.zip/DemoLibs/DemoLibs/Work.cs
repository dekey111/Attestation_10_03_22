﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLibs
{
	public class Work
	{
		public class Student
		{
			public string FIO { get; set; }
			public int Group { get; set; }
			public int Year { get; set; }

			public Student(string fio, int group, int year)
			{
				this.FIO = fio;
				this.Group = group;
				this.Year = year;
			}

			public void PrintInfo()
			{
				Console.WriteLine($"ФИО: {FIO}, Группа: {Group}, Год поступления: {Year}");
			}
		}
		public class Mark
		{
			public DateTime Attendance { get; set; }
			public string Estimation { get; set; }
			public Mark(DateTime attend, string estimation)
			{
				this.Attendance = attend;
				this.Estimation = estimation;
			}
			public void PrintInfo()
			{
				Console.WriteLine($"Дата: {Attendance}, Оценка: {Estimation}");
			}
		}
		public List<Mark> GetMarks(DateTime now, List<Student> students)
		{
			Random random = new Random();
			List<String> mt = new List<string> { "2", "3", "4", "5", "прогул", "болезнь", "УП" };
			List<Mark> marks = new List<Mark> { };
			for (int i = 0; i < students.Count; i++)
			{
				for (int j = 0; j < 10; j++)
				{
					Mark mark = new Mark(now.AddDays(j), mt[random.Next(0, 7)]);
					marks.Add(mark);
				}
			}
			return marks;
		}
		public int[] GetCountTruancy(List<Mark> marks)
		{
			Dictionary<int, int> res = new Dictionary<int, int>();
			var ttt = (from m in marks
					   group m by m.Attendance.Month into g
					   select new { Attendance = g.Key }).ToList();
			foreach (var t in ttt)
			{
				int prom = marks.FindAll(m => m.Attendance.Month == t.Attendance && m.Estimation == "прогул").Count;
				res.Add(t.Attendance, prom);
			}
			return res.Select(x => x.Value).ToArray();
		}

		public int[] GetCountDisease(List<Mark> marks)
		{

			Dictionary<int, int> res = new Dictionary<int, int>();
			var ttt = (from m in marks
					   group m by m.Attendance.Month into g
					   select new { Attendance = g.Key }).ToList();
			foreach (var t in ttt)
			{
				int prom = marks.FindAll(m => m.Attendance.Month == t.Attendance && m.Estimation == "болезнь").Count;
				res.Add(t.Attendance, prom);
			}
			return res.Select(x => x.Value).ToArray();
		}


		public double MinAVG(string[] marks)
		{
			int avg = 0;
			int count = marks.Count();
			for (int i = 0; i < count; i++)
			{
				avg += int.Parse(marks[i]);
			}
			return avg / count;
		}

		public string GetStudNumber(int year, int group, string fio)
		{
			string fioSub = "";
			int count = 0;
			string[] words = fio.Split(new char[] { ' ' });
			foreach (string s in words)
			{
				if (count == 3)
				{
					fioSub = "";
					count = 0;
				}
				fioSub += s.Substring(0, 1);
				count++;
			}
			return year + "." + group + "." + fioSub;
		} 
	}

}
   

